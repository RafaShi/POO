package soma;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int a, b, soma;
		
		System.out.println("Escreva um número: ");
		a = sc.nextInt();
		
		System.out.println("Escreva outro número: ");
		b = sc.nextInt();
		
		soma = a + b;
		
		System.out.println("Soma = "+ soma);
		

	}

}
