
import java.util.Scanner;

/**
 *
 * @author Rafaela Yumi
 */
public class aplic {

    public static void main(String[] args) {

        int identificacao, opcao, diasAtraso;
        String titulo;
        boolean situacao;
        double valMultaDiaria;

        Livro livro;

        situacao = false;

        Scanner sc = new Scanner(System.in);

        System.out.println("Escreva a identificação do livro: ");
        identificacao = sc.nextInt();

        System.out.println("Escreva o título do livro: ");
        titulo = sc.next();

        System.out.println("Escreva o valor da multa diária: ");
        valMultaDiaria = sc.nextDouble();

        livro = new Livro(identificacao, titulo);
        livro.setValMultaDiaria(valMultaDiaria);

        do {
            System.out.println("------MENU------");
            System.out.println("1 - Consultar livro");
            System.out.println("2 - Emprestar livro");
            System.out.println("3 - Devolver livro");
            System.out.println("4 - Sair \n\n");
            System.out.println("Digite a opção: ");

            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Identificação: " + identificacao);
                    System.out.println("Título: " + titulo);
                    if (!situacao) {
                        System.out.println("Livro disponível");
                    } else {
                        System.out.println("Livro NÃO disponível");
                    }

                case 2: {

                }

            }

        }
    

    }
