/**
 *
 * @author Rafaela Yumi
 */
public class Livro {
    
    private int identificacao;
    private String titulo;
    private boolean situacao;
    private double valMultaDiaria;
}
