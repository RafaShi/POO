/**
 *
 * @author Rafaela Yumi
 */
public class Livro {
    
    private int identificacao;
    private String titulo;
    private boolean situacao;
    private double valMultaDiaria;
    
    public Livro (int id, String tit){
        identificacao = id;
        titulo = tit;
       situacao = false;
    }
    
    public void setValMultaDiaria(double valor){
        valMultaDiaria = valor;
    }
    
    public int getIdentificacao (){
        return identificacao;
    }
    
    public String getTitulo (){
        return titulo;
    }
    
    public boolean getSituacao (){
        return situacao;
    }
    
    public void emprestar (){
        if (!situacao){
            situacao = true;
            System.out.println("Operação de empréstimo realizada com sucesso!.");
        }
        else
            System.out.println("Não foi possível, o livro se encontra ja se encontra emprstado");
    }
    
    public double devolver (int diasAtraso){
        if (situacao){
            situacao = false;
            System.out.println("O livro já está disponível!");
        }
        else
            System.out.println("O livro já está disponível");
        
        if (diasAtraso > 0){
            double multa;
            multa = diasAtraso * valMultaDiaria;
            System.out.println("O valor da multa a ser pago é: R$ "+ multa);
        }
        else
            System.out.println("Não há mula a serem pagas");
        return 0;
    }
}
