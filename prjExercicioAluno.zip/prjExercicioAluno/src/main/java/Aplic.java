import java.util.Scanner;

public class Aplic{
    
    public static void main(String[] args){
        
        Scanner entrada = new Scanner(System.in);
        Aluno aluno = new Aluno();


        System.out.print("Digite o RA do aluno: ");
        aluno.setRA(entrada.nextInt());

        System.out.print("Digite a nota da primeira prova: ");
        aluno.setNtPrv1(entrada.nextDouble());

        System.out.print("Digite a nota da segunda prova: ");
        aluno.setNtPrv2(entrada.nextDouble());

        System.out.print("Digite a nota do primeiro trabalho: ");
        aluno.setNtTrab1(entrada.nextDouble());

        System.out.print("Digite a nota do segundo trabalho: ");
        aluno.setNtTrab2(entrada.nextDouble());


        System.out.println("\nRA do Aluno: " + aluno.getRA());
        System.out.println("Média das Provas: " + aluno.calcMediaProva());
        System.out.println("Média dos Trabalhos: " + aluno.calcMediaTrab());
        System.out.println("Média Final: " + aluno.calcMediaFinal());

        entrada.close();
    }
}

 