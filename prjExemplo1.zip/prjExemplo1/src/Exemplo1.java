/**
 *
 * @author Rafaela
 */
public class Exemplo1 {

    public static void main(String[] args) {
        int idade;
        double peso;
        char sexo;
        String nome;
        
        idade = 34;
        peso = 78.5;
        sexo = 'F';
        nome = "Ana Beatriz";
        
        System.out.println("idade: " + idade);
        System.out.println("peso: " + peso);
        System.out.println("sexo: " + sexo);
        System.out.println("nome: " + nome);
    }
    
}
s